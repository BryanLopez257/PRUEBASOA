<?php
require_once "conexion.php";
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // Permite peticiones desde cualquier origen

$objeto = new Conexion();
$db = $objeto->Conectar();
$metodo = $_SERVER['REQUEST_METHOD'];

// --- MANEJO DE PETICIONES GET ---
if ($metodo == 'GET') {
    $action = $_GET['action'] ?? '';

    switch ($action) {
        case 'listar_clientes':
            $stmt = $db->prepare("SELECT cedula AS CEDULA, nombre AS NOMBRE, apellido AS APELLIDO FROM clientes");
            $stmt->execute();
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;

        case 'buscar_cliente':
            $cedula = $_GET['CEDULA'] ?? '';
            $stmt = $db->prepare("SELECT cedula AS CEDULA, nombre AS NOMBRE, apellido AS APELLIDO FROM clientes WHERE cedula = :ced");
            $stmt->bindParam(':ced', $cedula);
            $stmt->execute();
            echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
            break;

        case 'ver_pedidos':
            $nombre = $_GET['NOMBRE'] ?? '';
            $apellido = $_GET['APELLIDO'] ?? '';
            // Buscamos pedidos uniendo tablas por nombre y apellido
            $sql = "SELECT p.id AS ID_PED, pr.nombre_producto AS NOM_PRO, 1 AS CANT_PED, 'N/A' AS TOTAL 
                    FROM pedidos p 
                    INNER JOIN clientes c ON p.cedula_cliente = c.cedula
                    INNER JOIN productos pr ON p.id_producto = pr.id
                    WHERE c.nombre = :nom AND c.apellido = :ape";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':nom', $nombre);
            $stmt->bindParam(':ape', $apellido);
            $stmt->execute();
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;
    }
}

// --- MANEJO DE PETICIONES POST ---
if ($metodo == 'POST') {
    // jQuery envía los datos como $_POST normalmente, no como JSON crudo
    $nombre = $_POST['NOMBRE'] ?? '';
    $apellido = $_POST['APELLIDO'] ?? '';
    $nom_producto = $_POST['NOM_PRO'] ?? '';

    // 1. Buscar la cédula del cliente por su nombre/apellido (para cumplir el requisito de cliente existente)
    $stmtCli = $db->prepare("SELECT cedula FROM clientes WHERE nombre = :nom AND apellido = :ape LIMIT 1");
    $stmtCli->execute([':nom' => $nombre, ':ape' => $apellido]);
    $cliente = $stmtCli->fetch(PDO::FETCH_ASSOC);

    // 2. Buscar el ID del producto por su nombre
    $stmtProd = $db->prepare("SELECT id FROM productos WHERE nombre_producto = :np LIMIT 1");
    $stmtProd->execute([':np' => $nom_producto]);
    $producto = $stmtProd->fetch(PDO::FETCH_ASSOC);

    if ($cliente && $producto) {
        $sql = "INSERT INTO pedidos (cedula_cliente, id_producto) VALUES (:ced, :pid)";
        $ins = $db->prepare($sql);
        if ($ins->execute([':ced' => $cliente['cedula'], ':pid' => $producto['id']])) {
            echo json_encode(["message" => "Pedido registrado con éxito"]);
        } else {
            echo json_encode(["error" => "Error al insertar en la base de datos"]);
        }
    } else {
        echo json_encode(["error" => "Cliente o Producto no encontrado"]);
    }
}
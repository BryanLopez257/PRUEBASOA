<?php
require_once "Conexion.php";
header("Content-Type: application/json");

$objeto = new Conexion();
$db = $objeto->Conectar();

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo == 'GET') {
    // Visualizar pedidos por cliente con sus detalles (JOIN)
    if (isset($_GET['cedula'])) {
        $cedula = $_GET['cedula'];
        $sql = "SELECT p.id, pr.nombre_producto 
                FROM pedidos p 
                INNER JOIN productos pr ON p.id_producto = pr.id 
                WHERE p.cedula_cliente = :ced";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':ced', $cedula);
        $stmt->execute();
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
} 

if ($metodo == 'POST') {
    // Registrar nuevo pedido
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!empty($data['cedula']) && !empty($data['id_producto'])) {
        $sql = "INSERT INTO pedidos (cedula_cliente, id_producto) VALUES (:ced, :prod)";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':ced', $data['cedula']);
        $stmt->bindParam(':prod', $data['id_producto']);
        
        if ($stmt->execute()) {
            echo json_encode(["status" => "ok", "msj" => "Pedido guardado"]);
        } else {
            echo json_encode(["status" => "error", "msj" => "Error al guardar"]);
        }
    }
}
?>
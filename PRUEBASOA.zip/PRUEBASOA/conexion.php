<?php
class Conexion{
    public function Conectar(){
        $server="localhost";
        $user="root";
        $password="";
        $database="ventas";
        try{
            $conn=new PDO("mysql:host=$server;dbname=$database",$user,$password);
            //echo("Se conecto");
        }catch(Exception $ex){
            die("Fallo de conexion".$ex->getMessage());
        }
        return $conn;
    }
}
?>
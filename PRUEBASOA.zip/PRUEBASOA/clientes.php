<?php
require_once "Conexion.php";
header("Content-Type: application/json");

$objeto = new Conexion();
$db = $objeto->Conectar();

// Si recibe una cédula por GET, busca un cliente específico
if (isset($_GET['cedula'])) {
    $cedula = $_GET['cedula'];
    $stmt = $db->prepare("SELECT * FROM clientes WHERE cedula = :ced");
    $stmt->bindParam(':ced', $cedula);
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    // Si no hay parámetro, lista todos los clientes
    $stmt = $db->prepare("SELECT * FROM clientes");
    $stmt->execute();
    $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

echo json_encode($resultado);
?>